from dataclasses import dataclass
import asyncio
import time
import weakref
import sys
from typing import List, Dict, Optional
from collections import defaultdict

# Add debugging print statements
print("Starting debug of code...")

class MetricCollector:
    def __init__(self):
        self._metrics = {}
        self._callbacks = []
        print("MetricCollector initialized")

    def register_callback(self, callback):
        print("MetricCollector: Registering callback")
        self._callbacks.append(weakref.ref(callback))

    def record_metric(self, name: str, value: float):
        print(f"MetricCollector: Recording metric {name} with value {value}")
        self._metrics[name] = value
        for cb_ref in self._callbacks:
            callback = cb_ref()
            if callback:
                print(f"MetricCollector: Invoking callback for metric {name}")
                callback(name, value)

class CacheManager:
    def __init__(self, max_size: int = 1000):
        self.cache = {}
        self.access_times = defaultdict(int)
        self.max_size = max_size
        print("CacheManager initialized with max_size:", max_size)
        
    def get(self, key: str) -> Optional[dict]:
        print(f"CacheManager: Attempting to retrieve key {key}")
        if key in self.cache:
            self.access_times[key] = time.time()
            print(f"CacheManager: Cache hit for key {key}")
            return self.cache[key]
        print(f"CacheManager: Cache miss for key {key}")
        return None
        
    def set(self, key: str, value: dict):
        print(f"CacheManager: Setting key {key}")
        if len(self.cache) >= self.max_size:
            # Fix potential bug: handle empty access_times
            if not self.access_times:
                print("CacheManager: Warning - access_times is empty")
                return
                
            oldest_key = min(self.access_times.items(), key=lambda x: x[1])[0]
            print(f"CacheManager: Evicting oldest key {oldest_key}")
            del self.cache[oldest_key]
            del self.access_times[oldest_key]
        self.cache[key] = value
        self.access_times[key] = time.time()

class DataProcessor:
    def __init__(self):
        self.results = []
        self.processing = False
        self.cache_manager = CacheManager()
        self.metric_collector = MetricCollector()
        print("DataProcessor initialized")
        
    async def process_batch(self, items: List[Dict]):
        print(f"DataProcessor: Processing batch of {len(items)} items")
        self.processing = True
        tasks = []
        
        for item in items:
            print(f"DataProcessor: Processing item with id {item['id']}")
            cache_key = str(item['id'])
            cached = self.cache_manager.get(cache_key)
            if cached:
                print(f"DataProcessor: Using cached result for item {item['id']}")
                self.results.append(cached)
                continue
                
            task = asyncio.create_task(self._process_item(item))
            tasks.append(task)
            
        if tasks:
            print(f"DataProcessor: Awaiting {len(tasks)} tasks")
            await asyncio.gather(*tasks)
        else:
            print("DataProcessor: No tasks to process (all cached)")
            
        self.processing = False
        print(f"DataProcessor: Batch processing complete. {len(self.results)} results")
        return self.results
    
    async def _process_item(self, item: Dict):
        print(f"DataProcessor: Processing individual item {item['id']}")
        await asyncio.sleep(0.01)  # Simulate processing time
        processed = {
            'id': item['id'],
            'value': item['value'] * 2 if item['value'] > 0 else 0,
            'processed_at': time.time()
        }
        print(f"DataProcessor: Item {item['id']} processed with result value {processed['value']}")
        self.cache_manager.set(str(item['id']), processed)
        self.results.append(processed)
        self.metric_collector.record_metric(f"processed_{item['id']}", processed['value'])

class StateManager:
    def __init__(self):
        self._states = {}
        self._transitions = defaultdict(list)
        self._current_state = None
        print("StateManager initialized")
        
    def add_transition(self, from_state: str, to_state: str, condition: callable):
        print(f"StateManager: Adding transition from {from_state} to {to_state}")
        self._transitions[from_state].append((to_state, condition))
        
    def set_state(self, state: str, data: Dict = None):
        print(f"StateManager: Setting state to {state} with data {data}")
        if state not in self._states:
            self._states[state] = data or {}
        
        if self._current_state:
            print(f"StateManager: Current state is {self._current_state}, checking transitions")
            transitions = self._transitions[self._current_state]
            for next_state, condition in transitions:
                try:
                    if condition(data):
                        print(f"StateManager: Transitioning from {self._current_state} to {next_state}")
                        self._current_state = next_state
                        return
                except Exception as e:
                    print(f"StateManager: Error in transition condition: {e}")
                    
        self._current_state = state
        print(f"StateManager: State set to {self._current_state}")

class QueueHandler:
    def __init__(self, max_size: int = 100):
        self.queue = asyncio.Queue(maxsize=max_size)
        self.processing = False
        self._consumers = []
        print(f"QueueHandler initialized with max_size {max_size}")
        
    async def push(self, item: Dict):
        print(f"QueueHandler: Pushing item {item['id']} to queue")
        await self.queue.put(item)
        print(f"QueueHandler: Queue size is now {self.queue.qsize()}")
        
    def add_consumer(self, consumer: callable):
        print("QueueHandler: Adding consumer")
        self._consumers.append(consumer)
        
    async def start_processing(self):
        print("QueueHandler: Starting queue processing")
        self.processing = True
        
        # Set a timeout to avoid infinite processing
        timeout = time.time() + 5  # 5 second timeout
        
        while self.processing:
            if time.time() > timeout:
                print("QueueHandler: Processing timeout reached, stopping")
                self.processing = False
                break
                
            if self.queue.empty():
                print("QueueHandler: Queue is empty, waiting...")
                await asyncio.sleep(0.1)
                continue
                
            try:
                print("QueueHandler: Getting item from queue")
                item = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                print(f"QueueHandler: Processing item {item['id']}")
                
                tasks = []
                for consumer in self._consumers:
                    print(f"QueueHandler: Calling consumer on item {item['id']}")
                    tasks.append(consumer(item))
                
                if tasks:
                    print(f"QueueHandler: Awaiting {len(tasks)} consumer tasks")
                    await asyncio.gather(*tasks)
                
                print(f"QueueHandler: Marking item {item['id']} as done")
                self.queue.task_done()
            except asyncio.TimeoutError:
                print("QueueHandler: Timeout waiting for queue item")
                break
            except Exception as e:
                print(f"QueueHandler: Error processing queue item: {e}")
                break
        
        print("QueueHandler: Processing loop ended")

class Application:
    def __init__(self):
        print("Application: Initializing")
        self.processor = DataProcessor()
        self.state_manager = StateManager()
        self.queue_handler = QueueHandler()
        self._setup_state_transitions()
        print("Application: Initialization complete")
        
    def _setup_state_transitions(self):
        print("Application: Setting up state transitions")
        self.state_manager.add_transition(
            'idle', 'processing',
            lambda x: x and x.get('items_count', 0) > 0
        )
        self.state_manager.add_transition(
            'processing', 'idle',
            lambda x: not self.processor.processing
        )
        
    async def process_items(self, items: List[Dict]):
        print(f"Application: Processing {len(items)} items")
        self.state_manager.set_state('idle', {'items_count': len(items)})
        
        # Bug fix: We're setting up a queue and adding items to it, but then we're 
        # also passing those same items directly to process_batch. This creates duplication.
        # Let's fix this by properly coordinating the queue and batch processing.
        
        # First, add items to queue
        for item in items:
            print(f"Application: Adding item {item['id']} to queue")
            await self.queue_handler.push(item)
        
        # Setup consumer    
        print("Application: Setting up consumer")
        self.queue_handler.add_consumer(self._process_single_item)
        
        # Start queue processing in a task so it doesn't block
        print("Application: Starting queue processing")
        queue_task = asyncio.create_task(self.queue_handler.start_processing())
        
        # Wait a bit for queue to process
        print("Application: Waiting for queue processing to start")
        await asyncio.sleep(0.5)
        
        # Process batch with the original items
        print("Application: Starting batch processing")
        results = await self.processor.process_batch(items)
        
        # Stop queue processing
        print("Application: Stopping queue handler")
        self.queue_handler.processing = False
        await asyncio.sleep(0.1)  # Give it time to stop
        
        return results
    
    async def _process_single_item(self, item: Dict):
        print(f"Application: Processing single item {item['id']}")
        self.state_manager.set_state('processing', {'current_item': item['id']})
        await asyncio.sleep(0.05)  # Simulate processing time
        print(f"Application: Completed processing item {item['id']}")

async def main():
    print("Main: Starting application")
    app = Application()
    test_items = [
        {'id': i, 'value': i * 1.5} 
        for i in range(5)
    ]
    
    print("Main: Calling process_items")
    results = await app.process_items(test_items)
    print(f"Main: Processed {len(results)} items")
    print("Main: Results:", results)
    print("Main: Execution complete")

if __name__ == "__main__":
    print("Script started")
    try:
        print("Running main with 10 second timeout")
        asyncio.run(asyncio.wait_for(main(), timeout=10.0))
        print("Main completed successfully")
    except asyncio.TimeoutError:
        print("ERROR: Main function timed out after 10 seconds")
    except Exception as e:
        print(f"ERROR: Uncaught exception: {e}")
    finally:
        print("Script finished")