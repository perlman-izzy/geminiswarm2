import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Search, Grid, List, Map, Download, Save, ExternalLink } from "lucide-react";
import { getResultFileUrl } from "@/lib/api";

// Types for venue results
type VenueFeatures = {
  pianoType: string;
  availability: string;
  hours: string;
};

type Venue = {
  id: string;
  name: string;
  description: string;
  address: string;
  isOpen: boolean;
  features: VenueFeatures;
};

// Types for facility results
type FacilityFeatures = {
  cleanliness: number;
  location: string;
  amenities: string;
  hours: string;
  isFree: boolean;
};

type Facility = {
  id: string;
  name: string;
  description: string;
  address: string;
  isOpen: boolean;
  features: FacilityFeatures;
};

// Types for list results
type ListVenue = {
  id: string;
  name: string;
  location: string;
  rating: string;
};

type ResultsData = {
  type: "venue" | "facility" | "list";
  data: Venue[] | Facility[] | ListVenue[];
};

type ResultsAreaProps = {
  isLoading: boolean;
  hasError: boolean;
  error?: string;
  queryResult?: any;
  retryQuery: () => void;
  modifyQuery: () => void;
};

export function ResultsArea({ 
  isLoading, 
  hasError, 
  error, 
  queryResult, 
  retryQuery, 
  modifyQuery 
}: ResultsAreaProps) {
  const [viewMode, setViewMode] = useState<"list" | "grid" | "map">("list");
  
  const getResultCount = () => {
    if (!queryResult || !queryResult.result || !queryResult.result.resultJson) {
      return 0;
    }
    return Array.isArray(queryResult.result.resultJson) ? queryResult.result.resultJson.length : 0;
  };

  const getResultType = () => {
    if (!queryResult || !queryResult.query) {
      return null;
    }
    return queryResult.query.queryType;
  };

  const downloadResult = () => {
    if (!queryResult || !queryResult.result) {
      return;
    }
    
    const url = getResultFileUrl(queryResult.result.id);
    window.open(url, '_blank');
  };
  
  // Initial State - No query run yet
  if (!isLoading && !queryResult && !hasError) {
    return (
      <div id="initial-state" className="flex-1 flex flex-col items-center justify-center p-8 text-center">
        <div className="w-20 h-20 rounded-full bg-primary-light bg-opacity-20 flex items-center justify-center mb-4">
          <Search className="h-10 w-10 text-primary" />
        </div>
        <h3 className="text-xl font-medium text-neutral-700 dark:text-neutral-300 mb-2">No Query Results Yet</h3>
        <p className="text-neutral-500 dark:text-neutral-400 max-w-md">Use the query builder on the left to create and run a location-based query.</p>
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
          <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg bg-white dark:bg-gray-800">
            <div className="flex items-center mb-2">
              <span className="material-icons text-primary mr-2">place</span>
              <h4 className="font-medium text-neutral-700 dark:text-neutral-300">Find Venues</h4>
            </div>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Search for venues with specific features or amenities.</p>
          </div>
          <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg bg-white dark:bg-gray-800">
            <div className="flex items-center mb-2">
              <span className="material-icons text-secondary mr-2">wc</span>
              <h4 className="font-medium text-neutral-700 dark:text-neutral-300">Find Facilities</h4>
            </div>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Locate public facilities matching your criteria.</p>
          </div>
          <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg bg-white dark:bg-gray-800">
            <div className="flex items-center mb-2">
              <span className="material-icons text-accent mr-2">format_list_bulleted</span>
              <h4 className="font-medium text-neutral-700 dark:text-neutral-300">Generate Lists</h4>
            </div>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Create lists of venues by category or type.</p>
          </div>
        </div>
      </div>
    );
  }

  // Loading State
  if (isLoading) {
    return (
      <div id="loading-state" className="flex-1 flex flex-col items-center justify-center p-8 text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
        <h3 className="text-xl font-medium text-neutral-700 dark:text-neutral-300 mb-2">Processing Your Query</h3>
        <p className="text-neutral-500 dark:text-neutral-400 max-w-md">GeminiSwarm is analyzing data sources to find the most accurate results.</p>
        <div className="mt-6 w-full max-w-md bg-neutral-100 dark:bg-neutral-800 rounded-full h-2.5">
          <div className="bg-primary h-2.5 rounded-full w-3/4 transition-all duration-1000"></div>
        </div>
        <p className="mt-2 text-sm text-neutral-500 dark:text-neutral-400">This may take a minute for complex queries</p>
      </div>
    );
  }

  // Error State
  if (hasError) {
    return (
      <div id="error-state" className="flex-1 flex flex-col items-center justify-center p-8 text-center">
        <div className="w-20 h-20 rounded-full bg-destructive-light bg-opacity-20 flex items-center justify-center mb-4">
          <span className="material-icons text-4xl text-destructive">error_outline</span>
        </div>
        <h3 className="text-xl font-medium text-neutral-700 dark:text-neutral-300 mb-2">Query Error</h3>
        <p className="text-neutral-500 dark:text-neutral-400 max-w-md">There was an error processing your query. GeminiSwarm is attempting to fix the issue.</p>
        <div className="mt-4 bg-neutral-50 dark:bg-gray-800 border border-neutral-200 dark:border-neutral-700 rounded-lg p-4 max-w-xl w-full text-left">
          <h4 className="font-medium text-neutral-700 dark:text-neutral-300 mb-2">Error Details</h4>
          <pre className="text-xs text-neutral-600 dark:text-neutral-400 bg-neutral-100 dark:bg-gray-900 p-3 rounded overflow-x-auto">
            <code>{error || "Unknown error occurred while processing the query."}</code>
          </pre>
          <div className="mt-3">
            <h4 className="font-medium text-neutral-700 dark:text-neutral-300 mb-1">Troubleshooting Progress</h4>
            <ul className="text-sm text-neutral-600 dark:text-neutral-400 space-y-1">
              <li className="flex items-start">
                <span className="material-icons text-secondary text-sm mr-1">check_circle</span>
                <span>Checking network connectivity</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-secondary text-sm mr-1">check_circle</span>
                <span>Verifying API credentials</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-accent text-sm mr-1">pending</span>
                <span>Attempting to reconnect to database</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-neutral-300 text-sm mr-1">circle</span>
                <span>Falling back to alternative data source</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-6 flex space-x-4">
          <Button 
            onClick={retryQuery}
            className="bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded-lg transition-colors duration-200 flex items-center"
          >
            <span className="material-icons mr-1">refresh</span>
            Retry Query
          </Button>
          <Button 
            onClick={modifyQuery}
            variant="outline"
            className="bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 py-2 px-4 rounded-lg transition-colors duration-200"
          >
            Modify Query
          </Button>
        </div>
      </div>
    );
  }

  // Results State
  return (
    <div id="results-state" className="flex-1 flex flex-col overflow-hidden">
      {/* Results Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-neutral-200 dark:border-neutral-800 p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
          <h2 className="text-lg font-medium text-neutral-700 dark:text-neutral-300">Results</h2>
          <div className="flex items-center space-x-2 mt-2 sm:mt-0">
            <span id="results-count" className="text-sm text-neutral-600 dark:text-neutral-400">
              {getResultCount()} results
            </span>
            <div className="flex items-center border border-neutral-300 dark:border-neutral-700 rounded-lg overflow-hidden">
              <Button 
                variant="ghost" 
                size="sm" 
                className={`p-2 ${viewMode === 'list' ? 'bg-neutral-100 dark:bg-neutral-800' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className={`p-2 ${viewMode === 'grid' ? 'bg-neutral-100 dark:bg-neutral-800' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className={`p-2 ${viewMode === 'map' ? 'bg-neutral-100 dark:bg-neutral-800' : ''}`}
                onClick={() => setViewMode('map')}
              >
                <Map className="h-4 w-4" />
              </Button>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300"
              onClick={downloadResult}
            >
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Results Content based on query type */}
      <div className="flex-1 overflow-y-auto p-4">
        {getResultType() === 'venue' && queryResult?.result?.resultJson && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {queryResult.result.resultJson.map((venue: Venue) => (
              <div key={venue.id} className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-neutral-700 dark:text-neutral-300">{venue.name}</h3>
                    <span className="bg-secondary-light bg-opacity-20 text-secondary text-xs px-2 py-1 rounded-full">
                      {venue.isOpen ? "Open" : "Closed"}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">{venue.description}</p>
                  <div className="mt-2 flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                    <span className="material-icons text-neutral-400 dark:text-neutral-500 text-sm mr-1">place</span>
                    <span>{venue.address}</span>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Piano Type:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.pianoType}</span>
                    </div>
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Availability:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.availability}</span>
                    </div>
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Hours:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.hours}</span>
                    </div>
                  </div>
                  <div className="mt-4 flex space-x-2">
                    <Button className="bg-primary text-white py-1 px-3 rounded text-sm hover:bg-primary-dark transition-colors duration-200">
                      View Details
                    </Button>
                    <Button variant="outline" className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200">
                      Save
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {getResultType() === 'facility' && queryResult?.result?.resultJson && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {queryResult.result.resultJson.map((facility: Facility) => (
              <div key={facility.id} className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-neutral-700 dark:text-neutral-300">{facility.name}</h3>
                    <span className="bg-secondary-light bg-opacity-20 text-secondary text-xs px-2 py-1 rounded-full">
                      {facility.isOpen ? "Open" : "Closed"}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">{facility.description}</p>
                  <div className="mt-2 flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                    <span className="material-icons text-neutral-400 dark:text-neutral-500 text-sm mr-1">place</span>
                    <span>{facility.address}</span>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Cleanliness:</span>
                      <div className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <span key={i} className={`material-icons text-${i < facility.features.cleanliness ? 'accent' : 'neutral-300 dark:text-neutral-600'} text-sm`}>
                            star
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Location:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.location}</span>
                    </div>
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Features:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.amenities}</span>
                    </div>
                    <div className="flex">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Hours:</span>
                      <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.hours}</span>
                    </div>
                  </div>
                  <div className="mt-4 flex space-x-2">
                    <Button className="bg-primary text-white py-1 px-3 rounded text-sm hover:bg-primary-dark transition-colors duration-200">
                      View Details
                    </Button>
                    <Button variant="outline" className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200">
                      Get Directions
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {getResultType() === 'list' && queryResult?.result?.resultJson && (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden">
            <div className="p-4">
              <h3 className="font-medium text-neutral-700 dark:text-neutral-300 mb-3">
                {queryResult.result.resultJson[0]?.name.includes("Jazz") ? "Jazz Clubs" : "Venues"} in {queryResult.query.parameters.location}
              </h3>
              <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-4">
                Found {queryResult.result.resultJson.length} unique venues matching your criteria
              </p>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {queryResult.result.resultJson.map((venue: ListVenue) => (
                      <TableRow key={venue.id}>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                          {venue.id}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm font-medium text-neutral-700 dark:text-neutral-300">
                          {venue.name}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                          {venue.location}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                          {venue.rating}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                          <Button variant="link" className="text-primary hover:text-primary-dark transition-colors duration-200 p-0">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="mt-4 flex justify-between items-center">
                <div className="text-sm text-neutral-600 dark:text-neutral-400">
                  Showing {Math.min(queryResult.result.resultJson.length, 6)} of {queryResult.result.resultJson.length} results
                </div>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    disabled 
                    className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200"
                  >
                    Previous
                  </Button>
                  <Button 
                    disabled={queryResult.result.resultJson.length <= 6}
                    className="bg-primary text-white py-1 px-3 rounded text-sm hover:bg-primary-dark transition-colors duration-200"
                  >
                    Next
                  </Button>
                </div>
              </div>
              
              <div className="mt-4 flex space-x-2">
                <Button 
                  variant="outline" 
                  className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200 flex items-center"
                  onClick={downloadResult}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Export as CSV
                </Button>
                <Button 
                  variant="outline" 
                  className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200 flex items-center"
                  onClick={downloadResult}
                >
                  <span className="material-icons text-sm mr-1">text_snippet</span>
                  Export as Text
                </Button>
              </div>
            </div>
          </div>
        )}

        {getResultType() === 'custom' && queryResult?.result && (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden p-4">
            <h3 className="font-medium text-neutral-700 dark:text-neutral-300 mb-3">Custom Query Results</h3>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-4">
              {queryResult.query.queryText}
            </p>
            
            {/* Display the raw query result text */}
            <div className="mt-4 mb-6 bg-neutral-50 dark:bg-gray-900 border border-neutral-100 dark:border-neutral-800 rounded-lg p-4">
              <h4 className="font-medium text-neutral-700 dark:text-neutral-300 mb-2">Result</h4>
              <pre className="text-sm text-neutral-600 dark:text-neutral-400 whitespace-pre-wrap font-mono">
                {queryResult.result.resultText}
              </pre>
            </div>
            
            {/* Render based on detected type */}
            {Array.isArray(queryResult.result.resultJson) && queryResult.result.resultJson.length > 0 && (
              <>
                {queryResult.result.resultJson[0]?.hasOwnProperty('features') && queryResult.result.resultJson[0]?.features?.hasOwnProperty('pianoType') && (
                  // Venue type results
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {queryResult.result.resultJson.map((venue: Venue) => (
                      <div key={venue.id} className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
                        <div className="p-4">
                          <div className="flex justify-between items-start">
                            <h3 className="font-medium text-neutral-700 dark:text-neutral-300">{venue.name}</h3>
                            <span className="bg-secondary-light bg-opacity-20 text-secondary text-xs px-2 py-1 rounded-full">
                              {venue.isOpen ? "Open" : "Closed"}
                            </span>
                          </div>
                          <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">{venue.description}</p>
                          <div className="mt-2 flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                            <span className="material-icons text-neutral-400 dark:text-neutral-500 text-sm mr-1">place</span>
                            <span>{venue.address}</span>
                          </div>
                          <div className="mt-4 space-y-2">
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Piano Type:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.pianoType}</span>
                            </div>
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Availability:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.availability}</span>
                            </div>
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Hours:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{venue.features.hours}</span>
                            </div>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button className="bg-primary text-white py-1 px-3 rounded text-sm hover:bg-primary-dark transition-colors duration-200">
                              View Details
                            </Button>
                            <Button variant="outline" className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200">
                              Save
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {queryResult.result.resultJson[0].hasOwnProperty('features') && queryResult.result.resultJson[0].features.hasOwnProperty('cleanliness') && (
                  // Facility type results
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {queryResult.result.resultJson.map((facility: Facility) => (
                      <div key={facility.id} className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-neutral-700 shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
                        <div className="p-4">
                          <div className="flex justify-between items-start">
                            <h3 className="font-medium text-neutral-700 dark:text-neutral-300">{facility.name}</h3>
                            <span className="bg-secondary-light bg-opacity-20 text-secondary text-xs px-2 py-1 rounded-full">
                              {facility.isOpen ? "Open" : "Closed"}
                            </span>
                          </div>
                          <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">{facility.description}</p>
                          <div className="mt-2 flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                            <span className="material-icons text-neutral-400 dark:text-neutral-500 text-sm mr-1">place</span>
                            <span>{facility.address}</span>
                          </div>
                          <div className="mt-4 space-y-2">
                            <div className="flex items-center">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Cleanliness:</span>
                              <div className="flex">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <span key={i} className={`material-icons text-${i < facility.features.cleanliness ? 'accent' : 'neutral-300 dark:text-neutral-600'} text-sm`}>
                                    star
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Location:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.location}</span>
                            </div>
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Features:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.amenities}</span>
                            </div>
                            <div className="flex">
                              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 w-24">Hours:</span>
                              <span className="text-sm text-neutral-600 dark:text-neutral-400">{facility.features.hours}</span>
                            </div>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button className="bg-primary text-white py-1 px-3 rounded text-sm hover:bg-primary-dark transition-colors duration-200">
                              View Details
                            </Button>
                            <Button variant="outline" className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200">
                              Get Directions
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {queryResult.result.resultJson[0].hasOwnProperty('rating') && (
                  // List type results
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Rating</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {queryResult.result.resultJson.map((venue: ListVenue) => (
                          <TableRow key={venue.id}>
                            <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                              {venue.id}
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm font-medium text-neutral-700 dark:text-neutral-300">
                              {venue.name}
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                              {venue.location}
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                              {venue.rating}
                            </TableCell>
                            <TableCell className="whitespace-nowrap text-sm text-neutral-600 dark:text-neutral-400">
                              <Button variant="link" className="text-primary hover:text-primary-dark transition-colors duration-200 p-0">
                                View
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </>
            )}
            
            <div className="mt-4">
              <Button 
                variant="outline" 
                className="bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 py-1 px-3 rounded text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors duration-200 flex items-center"
                onClick={downloadResult}
              >
                <Download className="h-4 w-4 mr-1" />
                Download Results
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
