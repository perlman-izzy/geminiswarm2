import { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle, Clock, RefreshCw } from "lucide-react";

type AgentStatusProps = {
  agentState: 'idle' | 'processing' | 'completed' | 'error';
  currentTask?: string;
  progress?: number;
  errorMessage?: string;
};

export function AgentStatus({ 
  agentState = 'idle', 
  currentTask, 
  progress = 0, 
  errorMessage 
}: AgentStatusProps) {
  const [showSpinner, setShowSpinner] = useState(true);
  
  useEffect(() => {
    // Toggle spinner animation for visual effect
    if (agentState === 'processing') {
      const interval = setInterval(() => {
        setShowSpinner(prev => !prev);
      }, 700);
      
      return () => clearInterval(interval);
    }
  }, [agentState]);
  
  return (
    <Card className="p-4 border border-neutral-200 dark:border-neutral-700 shadow-sm bg-white dark:bg-gray-800">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Agent Status</h3>
        <Badge 
          variant={
            agentState === 'idle' ? 'outline' : 
            agentState === 'processing' ? 'secondary' : 
            agentState === 'completed' ? 'outline' : 'destructive'
          }
          className={`text-xs ${agentState === 'completed' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900' : ''}`}
        >
          {agentState === 'idle' && (
            <span className="flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              Idle
            </span>
          )}
          {agentState === 'processing' && (
            <span className="flex items-center">
              <RefreshCw className={`h-3 w-3 mr-1 ${showSpinner ? 'animate-spin' : ''}`} />
              Processing
            </span>
          )}
          {agentState === 'completed' && (
            <span className="flex items-center">
              <CheckCircle className="h-3 w-3 mr-1" />
              Completed
            </span>
          )}
          {agentState === 'error' && (
            <span className="flex items-center">
              <AlertCircle className="h-3 w-3 mr-1" />
              Error
            </span>
          )}
        </Badge>
      </div>
      
      {currentTask && (
        <div className="mb-3">
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">Current Task:</p>
          <p className="text-sm text-neutral-700 dark:text-neutral-300">{currentTask}</p>
        </div>
      )}
      
      {agentState === 'processing' && (
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-neutral-500 dark:text-neutral-400">Progress</span>
            <span className="text-xs text-neutral-700 dark:text-neutral-300">{progress}%</span>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      )}
      
      {agentState === 'error' && errorMessage && (
        <div className="mb-1 p-2 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded text-xs text-red-600 dark:text-red-300">
          {errorMessage}
        </div>
      )}
      
      <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
        <span>Last updated: {new Date().toLocaleTimeString()}</span>
        {agentState === 'processing' && (
          <span className="animate-pulse">Working...</span>
        )}
      </div>
    </Card>
  );
}