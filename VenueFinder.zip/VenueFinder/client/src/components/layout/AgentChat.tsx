import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SendIcon, BotIcon, UserIcon } from "lucide-react";

type Message = {
  id: string;
  sender: 'agent' | 'user';
  text: string;
  timestamp: Date;
  isSystemMessage?: boolean;
};

type AgentChatProps = {
  onSendMessage: (message: string) => void;
  onRequestCredentials?: (serviceType: string) => void;
};

export function AgentChat({ onSendMessage, onRequestCredentials }: AgentChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'agent',
      text: 'Hello! I am your location search agent. I can help you with complex queries about venues, facilities, and more. Feel free to ask me if you encounter any issues or need assistance.',
      timestamp: new Date(),
      isSystemMessage: true
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);
  
  const handleSendMessage = () => {
    if (inputValue.trim() === '') return;
    
    // Add user message to chat
    const newUserMessage: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputValue,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    
    // Call the parent component handler
    onSendMessage(inputValue);
    
    // Clear input
    setInputValue('');
  };
  
  // Function to add a message from the agent
  const addAgentMessage = (text: string, isSystemMessage = false) => {
    const newAgentMessage: Message = {
      id: Date.now().toString(),
      sender: 'agent',
      text,
      timestamp: new Date(),
      isSystemMessage
    };
    
    setMessages(prev => [...prev, newAgentMessage]);
  };
  
  // Expose addAgentMessage to parent component
  useEffect(() => {
    window.addAgentMessage = addAgentMessage;
  }, []);
  
  return (
    <Card className="flex flex-col h-full border border-neutral-200 dark:border-neutral-700 shadow-sm bg-white dark:bg-gray-800">
      <div className="px-4 py-3 border-b border-neutral-200 dark:border-neutral-700 flex items-center">
        <BotIcon className="h-5 w-5 mr-2 text-primary" />
        <h3 className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Agent Interaction</h3>
      </div>
      
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] p-3 rounded-lg ${
                  message.sender === 'user' 
                    ? 'bg-primary text-white rounded-tr-none' 
                    : message.isSystemMessage
                      ? 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-tl-none'
                      : 'bg-secondary-light text-neutral-700 dark:text-neutral-300 rounded-tl-none'
                }`}
              >
                <div className="flex items-center mb-1">
                  {message.sender === 'agent' ? (
                    <BotIcon className="h-3 w-3 mr-1" />
                  ) : (
                    <UserIcon className="h-3 w-3 mr-1" />
                  )}
                  <span className="text-xs font-medium">
                    {message.sender === 'agent' ? 'Agent' : 'You'}
                  </span>
                  <span className="text-xs ml-2 opacity-70">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                
                {/* Render credential request buttons if this is a credential request message */}
                {message.sender === 'agent' && message.text.includes('API key') && onRequestCredentials && (
                  <div className="mt-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="text-xs bg-white dark:bg-gray-800 mr-2"
                      onClick={() => onRequestCredentials('googlemaps')}
                    >
                      Provide Google Maps API Key
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="text-xs bg-white dark:bg-gray-800"
                      onClick={() => onRequestCredentials('openai')}
                    >
                      Provide OpenAI API Key
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
      
      <div className="p-4 border-t border-neutral-200 dark:border-neutral-700">
        <div className="flex items-center">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type a message to the agent..."
            className="flex-grow"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
            className="ml-2 bg-primary hover:bg-primary-dark text-white"
          >
            <SendIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}

// Add to window object for external access
declare global {
  interface Window {
    addAgentMessage: (text: string, isSystemMessage?: boolean) => void;
  }
}