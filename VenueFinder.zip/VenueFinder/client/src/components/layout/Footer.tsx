export function Footer() {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-neutral-200 dark:border-neutral-800 py-3 px-4">
      <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center">
        <div className="text-sm text-neutral-500 dark:text-neutral-400 mb-2 sm:mb-0">
          GeminiSwarm Location Intelligence v1.0
        </div>
        <div className="flex space-x-4">
          <a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary transition-colors duration-200">About</a>
          <a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary transition-colors duration-200">Documentation</a>
          <a href="https://github.com/perlman-izzy/geminiswarm1" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary transition-colors duration-200">GitHub</a>
        </div>
      </div>
    </footer>
  );
}
