import { useTheme } from "@/components/ui/theme-provider";
import { Button } from "@/components/ui/button";
import { Moon, Sun, HelpCircle, Settings } from "lucide-react";

export function Header() {
  const { theme, setTheme } = useTheme();
  
  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="material-icons text-primary text-2xl">language</span>
          <h1 className="text-xl font-medium text-neutral-700 dark:text-neutral-200">GeminiSwarm</h1>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-neutral-600 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          >
            {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
            <span className="hidden sm:inline ml-1">
              {theme === "light" ? "Dark" : "Light"}
            </span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-neutral-600 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
          >
            <HelpCircle size={18} />
            <span className="hidden sm:inline ml-1">Help</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-neutral-600 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
          >
            <Settings size={18} />
            <span className="hidden sm:inline ml-1">Settings</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
