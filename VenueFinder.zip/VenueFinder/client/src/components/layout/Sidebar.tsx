import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { PlayIcon, SaveIcon, DeleteIcon } from "lucide-react";
import { VenueQueryParams, FacilityQueryParams, ListQueryParams, CustomQueryParams } from "@shared/schema";

type SidebarProps = {
  onRunQuery: (
    queryType: string, 
    params: VenueQueryParams | FacilityQueryParams | ListQueryParams | CustomQueryParams
  ) => void;
  isLoading: boolean;
};

export function Sidebar({ onRunQuery, isLoading }: SidebarProps) {
  const [activeTab, setActiveTab] = useState<string>("preset");
  const [queryType, setQueryType] = useState<string>("venue");
  
  // Venue query form state
  const [venueLocation, setVenueLocation] = useState<string>("San Francisco");
  const [venueFeature, setVenueFeature] = useState<string>("piano");
  const [venueOpenNow, setVenueOpenNow] = useState<boolean>(false);
  
  // Facility query form state
  const [facilityLocation, setFacilityLocation] = useState<string>("San Francisco");
  const [facilityType, setFacilityType] = useState<string>("toilet");
  const [facilityClean, setFacilityClean] = useState<boolean>(true);
  const [facilityFree, setFacilityFree] = useState<boolean>(true);
  const [facilityGround, setFacilityGround] = useState<boolean>(true);
  
  // List query form state
  const [listLocation, setListLocation] = useState<string>("New York City");
  const [listCategory, setListCategory] = useState<string>("jazz club");
  const [listCount, setListCount] = useState<number>(20);
  const [listUnique, setListUnique] = useState<boolean>(true);
  
  // Custom query form state
  const [customQueryText, setCustomQueryText] = useState<string>("");
  
  const handleRunQuery = () => {
    if (activeTab === "preset") {
      switch (queryType) {
        case "venue":
          onRunQuery("venue", {
            location: venueLocation,
            feature: venueFeature,
            openNow: venueOpenNow
          });
          break;
        case "facility":
          onRunQuery("facility", {
            location: facilityLocation,
            facilityType: facilityType,
            clean: facilityClean,
            free: facilityFree,
            notAboveGround: facilityGround
          });
          break;
        case "list":
          onRunQuery("list", {
            location: listLocation,
            category: listCategory,
            count: listCount,
            unique: listUnique
          });
          break;
      }
    } else {
      // Custom query
      onRunQuery("custom", {
        queryText: customQueryText
      });
    }
  };
  
  const handleClearForm = () => {
    if (activeTab === "preset") {
      switch (queryType) {
        case "venue":
          setVenueLocation("");
          setVenueFeature("");
          setVenueOpenNow(false);
          break;
        case "facility":
          setFacilityLocation("");
          setFacilityType("toilet");
          setFacilityClean(false);
          setFacilityFree(false);
          setFacilityGround(false);
          break;
        case "list":
          setListLocation("");
          setListCategory("");
          setListCount(10);
          setListUnique(false);
          break;
      }
    } else {
      // Clear custom query
      setCustomQueryText("");
    }
  };
  
  return (
    <aside className="w-full md:w-80 bg-white dark:bg-gray-900 border-r border-neutral-200 dark:border-neutral-800 flex flex-col">
      <div className="p-4 border-b border-neutral-200 dark:border-neutral-800">
        <h2 className="text-lg font-medium text-neutral-700 dark:text-neutral-200 mb-1">Query Builder</h2>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">Create complex location queries</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="w-full border-b border-neutral-200 dark:border-neutral-800 rounded-none">
          <TabsTrigger 
            value="preset" 
            className="flex-1 py-3 px-4 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
          >
            Preset Queries
          </TabsTrigger>
          <TabsTrigger 
            value="custom" 
            className="flex-1 py-3 px-4 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
          >
            Custom Query
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="preset" className="flex-1 flex flex-col overflow-y-auto p-4 space-y-4">
          <div>
            <Label htmlFor="query-type" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Query Type
            </Label>
            <Select value={queryType} onValueChange={setQueryType}>
              <SelectTrigger id="query-type" className="w-full">
                <SelectValue placeholder="Select query type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="venue">Find venues with features</SelectItem>
                <SelectItem value="facility">Find facilities with criteria</SelectItem>
                <SelectItem value="list">Generate venue list</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Venue Query Options */}
          {queryType === "venue" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="venue-location" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Location
                </Label>
                <Input
                  id="venue-location"
                  value={venueLocation}
                  onChange={(e) => setVenueLocation(e.target.value)}
                  placeholder="Enter city or area"
                />
              </div>
              <div>
                <Label htmlFor="venue-feature" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Feature/Amenity
                </Label>
                <Input
                  id="venue-feature"
                  value={venueFeature}
                  onChange={(e) => setVenueFeature(e.target.value)}
                  placeholder="e.g., piano, outdoor seating"
                />
              </div>
              <div className="flex items-start space-x-2">
                <Checkbox 
                  id="venue-open-now" 
                  checked={venueOpenNow}
                  onCheckedChange={(checked) => setVenueOpenNow(checked as boolean)}
                />
                <Label htmlFor="venue-open-now" className="text-sm text-neutral-600 dark:text-neutral-400">
                  Currently open
                </Label>
              </div>
            </div>
          )}

          {/* Facility Query Options */}
          {queryType === "facility" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="facility-location" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Location
                </Label>
                <Input
                  id="facility-location"
                  value={facilityLocation}
                  onChange={(e) => setFacilityLocation(e.target.value)}
                  placeholder="Enter city or area"
                />
              </div>
              <div>
                <Label htmlFor="facility-type" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Facility Type
                </Label>
                <Select value={facilityType} onValueChange={setFacilityType}>
                  <SelectTrigger id="facility-type" className="w-full">
                    <SelectValue placeholder="Select facility type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="toilet">Public Toilet</SelectItem>
                    <SelectItem value="wifi">Free WiFi</SelectItem>
                    <SelectItem value="water">Water Fountain</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300">
                  Additional Criteria
                </Label>
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="facility-clean" 
                    checked={facilityClean}
                    onCheckedChange={(checked) => setFacilityClean(checked as boolean)}
                  />
                  <Label htmlFor="facility-clean" className="text-sm text-neutral-600 dark:text-neutral-400">
                    Clean facilities
                  </Label>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="facility-free" 
                    checked={facilityFree}
                    onCheckedChange={(checked) => setFacilityFree(checked as boolean)}
                  />
                  <Label htmlFor="facility-free" className="text-sm text-neutral-600 dark:text-neutral-400">
                    Free to use
                  </Label>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="facility-ground" 
                    checked={facilityGround}
                    onCheckedChange={(checked) => setFacilityGround(checked as boolean)}
                  />
                  <Label htmlFor="facility-ground" className="text-sm text-neutral-600 dark:text-neutral-400">
                    Not on above-ground floor
                  </Label>
                </div>
              </div>
            </div>
          )}

          {/* List Query Options */}
          {queryType === "list" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="list-location" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Location
                </Label>
                <Input
                  id="list-location"
                  value={listLocation}
                  onChange={(e) => setListLocation(e.target.value)}
                  placeholder="Enter city or area"
                />
              </div>
              <div>
                <Label htmlFor="list-category" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Venue Category
                </Label>
                <Input
                  id="list-category"
                  value={listCategory}
                  onChange={(e) => setListCategory(e.target.value)}
                  placeholder="e.g., jazz club, pizza restaurant"
                />
              </div>
              <div>
                <Label htmlFor="list-count" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Number of Venues
                </Label>
                <Input
                  id="list-count"
                  type="number"
                  value={listCount.toString()}
                  onChange={(e) => setListCount(parseInt(e.target.value) || 10)}
                  min={1}
                  max={100}
                />
              </div>
              <div className="flex items-start space-x-2">
                <Checkbox 
                  id="list-unique" 
                  checked={listUnique}
                  onCheckedChange={(checked) => setListUnique(checked as boolean)}
                />
                <Label htmlFor="list-unique" className="text-sm text-neutral-600 dark:text-neutral-400">
                  Ensure unique venues only
                </Label>
              </div>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="custom" className="flex-1 flex flex-col overflow-y-auto p-4 space-y-4">
          <div>
            <Label htmlFor="custom-query-text" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Custom Query
            </Label>
            <Textarea 
              id="custom-query-text" 
              value={customQueryText}
              onChange={(e) => setCustomQueryText(e.target.value)}
              placeholder="Enter your custom query here..."
              rows={6}
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Action Buttons */}
      <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
        <Button 
          onClick={handleRunQuery} 
          disabled={isLoading}
          className="w-full bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center"
        >
          <PlayIcon className="mr-1 h-4 w-4" />
          {isLoading ? "Processing..." : "Run Query"}
        </Button>
        <div className="mt-2 flex space-x-2">
          <Button
            variant="outline"
            className="flex-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 py-2 px-4 rounded-lg transition-colors duration-200 text-sm"
          >
            <SaveIcon className="mr-1 h-4 w-4" />
            Save Query
          </Button>
          <Button
            variant="outline"
            onClick={handleClearForm}
            className="flex-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 py-2 px-4 rounded-lg transition-colors duration-200 text-sm"
          >
            <DeleteIcon className="mr-1 h-4 w-4" />
            Clear Form
          </Button>
        </div>
      </div>
    </aside>
  );
}
