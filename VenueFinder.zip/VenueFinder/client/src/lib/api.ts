import { apiRequest } from '@/lib/queryClient';
import { 
  VenueQueryParams, 
  FacilityQueryParams, 
  ListQueryParams, 
  CustomQueryParams,
  Query,
  Result
} from '@shared/schema';

// API functions for queries
export async function runVenueQuery(params: VenueQueryParams) {
  const response = await apiRequest('POST', '/api/query', {
    queryType: 'venue',
    parameters: params
  });
  return response.json();
}

export async function runFacilityQuery(params: FacilityQueryParams) {
  const response = await apiRequest('POST', '/api/query', {
    queryType: 'facility',
    parameters: params
  });
  return response.json();
}

export async function runListQuery(params: ListQueryParams) {
  const response = await apiRequest('POST', '/api/query', {
    queryType: 'list',
    parameters: params
  });
  return response.json();
}

export async function runCustomQuery(params: CustomQueryParams) {
  const response = await apiRequest('POST', '/api/query', {
    queryType: 'custom',
    parameters: params
  });
  return response.json();
}

// API function to get recent queries
export async function getRecentQueries(limit?: number): Promise<Query[]> {
  const url = limit ? `/api/queries/recent?limit=${limit}` : '/api/queries/recent';
  const response = await fetch(url, {
    credentials: 'include'
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch recent queries: ${response.statusText}`);
  }
  
  return response.json();
}

// API function to get results for a query
export async function getQueryResults(queryId: number): Promise<Result[]> {
  const response = await fetch(`/api/query/${queryId}/results`, {
    credentials: 'include'
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch query results: ${response.statusText}`);
  }
  
  return response.json();
}

// API function to download a result file
export function getResultFileUrl(resultId: number): string {
  return `/api/result/${resultId}/download`;
}
