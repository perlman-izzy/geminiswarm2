import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Sidebar } from '@/components/layout/Sidebar';
import { ResultsArea } from '@/components/layout/ResultsArea';
import { AgentStatus } from '@/components/layout/AgentStatus';
import { AgentChat } from '@/components/layout/AgentChat';
import { 
  runVenueQuery, 
  runFacilityQuery, 
  runListQuery, 
  runCustomQuery 
} from '@/lib/api';
import { 
  VenueQueryParams, 
  FacilityQueryParams, 
  ListQueryParams, 
  CustomQueryParams 
} from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Drawer, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

export default function Home() {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<string | undefined>(undefined);
  const [queryResult, setQueryResult] = useState<any | null>(null);
  const [lastQueryParams, setLastQueryParams] = useState<any | null>(null);
  const [lastQueryType, setLastQueryType] = useState<string | null>(null);
  
  // Agent state
  const [agentState, setAgentState] = useState<'idle' | 'processing' | 'completed' | 'error'>('idle');
  const [currentTask, setCurrentTask] = useState<string | undefined>(undefined);
  const [progress, setProgress] = useState<number>(0);
  const [taskSteps, setTaskSteps] = useState<string[]>([]);
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  
  const { toast } = useToast();
  
  // Update agent status based on application state
  useEffect(() => {
    if (isLoading) {
      setAgentState('processing');
      setCurrentTask(`Processing ${lastQueryType} query...`);
      
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + Math.floor(Math.random() * 10);
          return newProgress > 90 ? 90 : newProgress;
        });
      }, 1000);
      
      return () => clearInterval(progressInterval);
    } else if (hasError) {
      setAgentState('error');
      setCurrentTask('Error occurred during query processing');
    } else if (queryResult) {
      setAgentState('completed');
      setCurrentTask(`Successfully processed ${queryResult.query?.queryType} query`);
      setProgress(100);
      
      // Add agent message about successful query
      if (window.addAgentMessage) {
        window.addAgentMessage(`I've completed processing your ${queryResult.query?.queryType} query. The results are now displayed and have been saved to a file.`);
      }
    } else {
      setAgentState('idle');
      setCurrentTask(undefined);
      setProgress(0);
    }
  }, [isLoading, hasError, queryResult, lastQueryType]);
  
  const handleRunQuery = async (
    queryType: string, 
    params: VenueQueryParams | FacilityQueryParams | ListQueryParams | CustomQueryParams
  ) => {
    setIsLoading(true);
    setHasError(false);
    setError(undefined);
    setLastQueryParams(params);
    setLastQueryType(queryType);
    setProgress(0);
    
    // Add a message to the agent chat
    if (window.addAgentMessage) {
      window.addAgentMessage(`I'm processing your ${queryType} query. This may take a moment...`);
    }
    
    // Record task steps
    setTaskSteps([`Initializing ${queryType} query`]);
    
    try {
      let result;
      
      // Add intermediate steps for better status reporting
      setTaskSteps(prev => [...prev, `Preparing query parameters`]);
      setProgress(20);
      
      // Short delay to make progress visible
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setTaskSteps(prev => [...prev, `Sending request to server`]);
      setProgress(40);
      
      // Execute the appropriate query
      switch (queryType) {
        case 'venue':
          result = await runVenueQuery(params as VenueQueryParams);
          break;
        case 'facility':
          result = await runFacilityQuery(params as FacilityQueryParams);
          break;
        case 'list':
          result = await runListQuery(params as ListQueryParams);
          break;
        case 'custom':
          result = await runCustomQuery(params as CustomQueryParams);
          break;
        default:
          throw new Error(`Invalid query type: ${queryType}`);
      }
      
      setTaskSteps(prev => [...prev, `Processing server response`]);
      setProgress(70);
      
      // Short delay for progress visualization
      await new Promise(resolve => setTimeout(resolve, 300));
      
      setTaskSteps(prev => [...prev, `Formatting results for display`]);
      setProgress(90);
      
      // Set the result data
      setQueryResult(result);
      
      // Add final step
      setTaskSteps(prev => [...prev, `Query completed successfully`]);
      setProgress(100);
      
      toast({
        title: "Query completed successfully",
        description: `Results saved to ${result.result.filePath}`,
      });
    } catch (err) {
      setHasError(true);
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
      
      // Update task steps with error
      setTaskSteps(prev => [...prev, `Error: ${err instanceof Error ? err.message : 'An unknown error occurred'}`]);
      
      // Add error message to agent chat
      if (window.addAgentMessage) {
        window.addAgentMessage(`I encountered an error while processing your query: ${err instanceof Error ? err.message : 'An unknown error occurred'}. Please try again or modify your query.`);
      }
      
      toast({
        variant: "destructive",
        title: "Query Error",
        description: err instanceof Error ? err.message : 'An unknown error occurred',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleRetryQuery = () => {
    if (lastQueryType && lastQueryParams) {
      handleRunQuery(lastQueryType, lastQueryParams);
    }
  };
  
  const handleModifyQuery = () => {
    setHasError(false);
    setError(undefined);
  };
  
  const handleSendMessage = (message: string) => {
    // Process user message and potentially update agent state
    if (window.addAgentMessage) {
      if (message.toLowerCase().includes('help') || message.toLowerCase().includes('how')) {
        window.addAgentMessage('I can help you search for venues with specific features, find facilities that match certain criteria, or create lists of locations. Try using the query builder on the left to get started!');
      } else if (message.toLowerCase().includes('error') || message.toLowerCase().includes('issue')) {
        window.addAgentMessage('I\'ll help you troubleshoot this issue. Could you provide more details about what specific error you\'re encountering?');
      } else if (message.toLowerCase().includes('credential') || message.toLowerCase().includes('api key')) {
        window.addAgentMessage('You can provide your API credentials by clicking on the "Provide API Key" button when prompted, or by entering them directly in this chat.');
      } else {
        window.addAgentMessage(`I've received your message: "${message}". Is there a specific query you'd like me to help you with?`);
      }
    }
  };
  
  const handleCredentialRequest = (serviceType: string) => {
    // Handle credential requests for different services
    if (window.addAgentMessage) {
      window.addAgentMessage(`I'll need your ${serviceType} API key to proceed with this operation. Please provide it in a secure manner.`);
    }
  };
  
  return (
    <div className="flex flex-col h-screen">
      <Header />
      
      <main className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <Sidebar onRunQuery={handleRunQuery} isLoading={isLoading} />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Status Bar */}
          <div className="p-3 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-gray-900">
            <AgentStatus 
              agentState={agentState}
              currentTask={currentTask}
              progress={progress}
              errorMessage={hasError ? error : undefined}
            />
          </div>
          
          {/* Main Content Area */}
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            <div className="flex-1 overflow-hidden">
              <ResultsArea 
                isLoading={isLoading}
                hasError={hasError}
                error={error}
                queryResult={queryResult}
                retryQuery={handleRetryQuery}
                modifyQuery={handleModifyQuery}
              />
            </div>
            
            {/* Agent Chat - Only visible on larger screens by default */}
            <div className="hidden md:block w-80 border-l border-neutral-200 dark:border-neutral-800">
              <AgentChat 
                onSendMessage={handleSendMessage}
                onRequestCredentials={handleCredentialRequest}
              />
            </div>
          </div>
        </div>
      </main>
      
      {/* Mobile Chat Button and Drawer */}
      <div className="md:hidden fixed bottom-16 right-4 z-10">
        <Drawer open={drawerOpen} onOpenChange={setDrawerOpen}>
          <DrawerTrigger asChild>
            <Button 
              size="icon" 
              className="h-12 w-12 rounded-full shadow-lg bg-primary hover:bg-primary-dark text-white"
            >
              <MessageCircle className="h-6 w-6" />
            </Button>
          </DrawerTrigger>
          <DrawerContent className="h-[80vh]">
            <AgentChat 
              onSendMessage={handleSendMessage}
              onRequestCredentials={handleCredentialRequest}
            />
          </DrawerContent>
        </Drawer>
      </div>
      
      <Footer />
    </div>
  );
}
