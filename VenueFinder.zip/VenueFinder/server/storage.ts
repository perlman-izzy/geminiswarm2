import { 
  users, type User, type InsertUser,
  queries, type Query, type InsertQuery,
  results, type Result, type InsertResult
} from "@shared/schema";
import fs from 'fs';
import path from 'path';

// Modify the interface with any CRUD methods
export interface IStorage {
  // User operations (required for the existing interface)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Query operations
  createQuery(query: InsertQuery): Promise<Query>;
  getQuery(id: number): Promise<Query | undefined>;
  getRecentQueries(limit?: number): Promise<Query[]>;

  // Result operations
  createResult(result: InsertResult): Promise<Result>;
  getResult(id: number): Promise<Result | undefined>;
  getResultsByQueryId(queryId: number): Promise<Result[]>;
  saveResultToFile(resultId: number): Promise<string>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private queriesMap: Map<number, Query>;
  private resultsMap: Map<number, Result>;
  private userId: number;
  private queryId: number;
  private resultId: number;
  private resultsDir: string;

  constructor() {
    this.users = new Map();
    this.queriesMap = new Map();
    this.resultsMap = new Map();
    this.userId = 1;
    this.queryId = 1;
    this.resultId = 1;
    
    // Create a directory for saving result files
    this.resultsDir = path.join(process.cwd(), 'results');
    if (!fs.existsSync(this.resultsDir)) {
      fs.mkdirSync(this.resultsDir, { recursive: true });
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Query operations
  async createQuery(insertQuery: InsertQuery): Promise<Query> {
    const id = this.queryId++;
    const query: Query = {
      ...insertQuery,
      id,
      createdAt: new Date(),
    };
    this.queriesMap.set(id, query);
    return query;
  }

  async getQuery(id: number): Promise<Query | undefined> {
    return this.queriesMap.get(id);
  }

  async getRecentQueries(limit: number = 10): Promise<Query[]> {
    return Array.from(this.queriesMap.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  // Result operations
  async createResult(insertResult: InsertResult): Promise<Result> {
    const id = this.resultId++;
    const result: Result = {
      ...insertResult,
      id,
      createdAt: new Date(),
      // Ensure all required properties have values
      resultJson: insertResult.resultJson || null,
      savedToFile: insertResult.savedToFile || false,
      filePath: insertResult.filePath || null
    };
    this.resultsMap.set(id, result);
    return result;
  }

  async getResult(id: number): Promise<Result | undefined> {
    return this.resultsMap.get(id);
  }

  async getResultsByQueryId(queryId: number): Promise<Result[]> {
    return Array.from(this.resultsMap.values())
      .filter(result => result.queryId === queryId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async saveResultToFile(resultId: number): Promise<string> {
    const result = await this.getResult(resultId);
    if (!result) {
      throw new Error(`Result with ID ${resultId} not found`);
    }

    // Generate a filename based on query ID and timestamp
    const query = await this.getQuery(result.queryId);
    if (!query) {
      throw new Error(`Query with ID ${result.queryId} not found`);
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    let filename = `${query.queryType}_${result.queryId}_${timestamp}.txt`;
    const filePath = path.join(this.resultsDir, filename);

    // Ensure results directory exists
    if (!fs.existsSync(this.resultsDir)) {
      fs.mkdirSync(this.resultsDir, { recursive: true });
      console.log(`Created results directory at ${this.resultsDir}`);
    }

    // Write the result text to file with error handling
    try {
      // First attempt: standard writeFileSync
      fs.writeFileSync(filePath, result.resultText);
      
      // Verify file was written successfully
      if (!fs.existsSync(filePath) || fs.statSync(filePath).size === 0) {
        throw new Error('File was not written successfully');
      }
      
      console.log(`Successfully saved result to file: ${filename}`);
    } catch (error) {
      console.error(`Error saving result to file: ${error instanceof Error ? error.message : String(error)}`);
      
      // Second attempt: alternative approach with stream
      try {
        const writeStream = fs.createWriteStream(filePath);
        writeStream.write(result.resultText);
        writeStream.end();
        
        // Wait for file to be written
        await new Promise((resolve, reject) => {
          writeStream.on('finish', resolve);
          writeStream.on('error', reject);
        });
        
        console.log(`Successfully saved result to file using stream: ${filename}`);
      } catch (streamError) {
        console.error(`Second attempt to save file failed: ${streamError instanceof Error ? streamError.message : String(streamError)}`);
        
        // Last resort: try with a different filename
        const backupFilename = `backup_${query.queryType}_${result.queryId}_${timestamp}.txt`;
        const backupPath = path.join(this.resultsDir, backupFilename);
        
        try {
          fs.writeFileSync(backupPath, result.resultText);
          console.log(`Used backup method to save file: ${backupFilename}`);
          
          // If backup succeeded, use this filename instead
          filename = backupFilename.slice();
        } catch (backupError) {
          console.error(`All file saving methods failed: ${backupError instanceof Error ? backupError.message : String(backupError)}`);
          throw new Error('Failed to save result to file after multiple attempts');
        }
      }
    }

    // Update the result record with file information
    const updatedResult: Result = {
      ...result,
      savedToFile: true,
      filePath: filename,
    };
    this.resultsMap.set(resultId, updatedResult);

    return filename;
  }
}

export const storage = new MemStorage();