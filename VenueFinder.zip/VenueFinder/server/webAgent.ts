import puppeteer from 'puppeteer';

interface TaskStep {
  type: string;
  action: string;
  data?: any;
  success?: boolean;
  message?: string;
}

interface WebTaskResult {
  success: boolean;
  taskSteps: TaskStep[];
  message?: string;
  error?: string;
}

/**
 * A general-purpose web agent that can perform a variety of web tasks
 */
export class WebAgent {
  private browser: puppeteer.Browser | null = null;
  private page: puppeteer.Page | null = null;
  private taskSteps: TaskStep[] = [];
  private isInitialized = false;

  /**
   * Initialize the web agent
   */
  async initialize(): Promise<void> {
    try {
      if (!this.isInitialized) {
        this.browser = await puppeteer.launch({
          headless: true,
          executablePath: '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium',
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--single-process',
            '--disable-gpu'
          ]
        });
        this.page = await this.browser.newPage();
        this.isInitialized = true;
      }
    } catch (error) {
      console.error('Failed to initialize web agent:', error);
      throw error;
    }
  }

  /**
   * Cleanup and close the browser
   */
  async cleanup(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
      this.isInitialized = false;
    }
  }

  /**
   * Execute a task with multiple steps
   * @param instructions Array of task instructions to execute
   */
  async executeTask(instructions: string[]): Promise<WebTaskResult> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    this.taskSteps = [];
    let success = true;

    try {
      // Process each instruction
      for (const instruction of instructions) {
        const trimmedInstruction = instruction.trim().toLowerCase();
        
        // Navigation instruction
        if (trimmedInstruction.includes('visit') || trimmedInstruction.includes('go to') || trimmedInstruction.includes('navigate')) {
          const url = this.extractUrl(instruction);
          if (url) {
            success = await this.navigateTo(url);
            if (!success) break;
          } else {
            this.taskSteps.push({
              type: 'navigation',
              action: 'visit',
              success: false,
              message: 'No valid URL found in instruction'
            });
            success = false;
            break;
          }
        } 
        // Authentication instruction
        else if (trimmedInstruction.includes('sign in') || trimmedInstruction.includes('login')) {
          const credentials = this.extractCredentials(instruction);
          if (credentials.username && credentials.password) {
            success = await this.authenticate(credentials.username, credentials.password);
            if (!success) break;
          } else {
            this.taskSteps.push({
              type: 'authentication',
              action: 'sign in',
              success: false,
              message: 'No valid credentials found in instruction'
            });
            success = false;
            break;
          }
        } 
        // Job application instruction
        else if (trimmedInstruction.includes('apply') && (trimmedInstruction.includes('job') || trimmedInstruction.includes('jobs'))) {
          const count = this.extractCount(instruction) || 3; // Default to 3 jobs if not specified
          success = await this.applyToJobs(count);
          if (!success) break;
        } 
        // Form filling instruction
        else if (trimmedInstruction.includes('fill') && trimmedInstruction.includes('form')) {
          success = await this.fillForms();
          if (!success) break;
        } 
        // Generic instruction
        else {
          this.taskSteps.push({
            type: 'unknown',
            action: instruction,
            success: true,
            message: 'Instruction processed but not specifically implemented'
          });
        }
      }

      return {
        success,
        taskSteps: this.taskSteps,
        message: success ? 'Task completed successfully' : 'Task failed'
      };
    } catch (error) {
      console.error('Error executing task:', error);
      return {
        success: false,
        taskSteps: this.taskSteps,
        message: 'Task failed with error',
        error: error instanceof Error ? error.message : String(error)
      };
    } finally {
      await this.cleanup();
    }
  }

  /**
   * Navigate to a URL
   * @param url The URL to navigate to
   */
  private async navigateTo(url: string): Promise<boolean> {
    try {
      if (!this.page) {
        throw new Error('Browser not initialized');
      }
      
      const step: TaskStep = {
        type: 'navigation',
        action: 'visit',
        data: { url }
      };
      
      await this.page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
      
      // Capture screenshot for validation
      const screenshot = await this.page.screenshot({ encoding: 'base64' });
      
      step.success = true;
      step.message = `Successfully navigated to ${url}`;
      this.taskSteps.push(step);
      
      return true;
    } catch (error) {
      console.error(`Error navigating to ${url}:`, error);
      this.taskSteps.push({
        type: 'navigation',
        action: 'visit',
        data: { url },
        success: false,
        message: `Failed to navigate to ${url}: ${error instanceof Error ? error.message : String(error)}`
      });
      return false;
    }
  }

  /**
   * Authenticate with username and password
   * @param username The username or email
   * @param password The password
   */
  private async authenticate(username: string, password: string): Promise<boolean> {
    try {
      if (!this.page) {
        throw new Error('Browser not initialized');
      }
      
      const step: TaskStep = {
        type: 'authentication',
        action: 'sign in',
        data: { username }
      };
      
      // Check if we're on LinkedIn
      const currentUrl = this.page.url();
      const isLinkedIn = currentUrl.includes('linkedin.com');
      
      if (isLinkedIn) {
        // Look for sign-in button if we're not already on the sign-in page
        if (!currentUrl.includes('linkedin.com/login')) {
          // Try to find and click sign-in button
          try {
            await this.page.waitForSelector('a[data-tracking-control-name="guest_homepage-basic_nav-header-signin"]', { timeout: 5000 });
            await this.page.click('a[data-tracking-control-name="guest_homepage-basic_nav-header-signin"]');
          } catch (e) {
            // If we can't find the sign-in button, try navigating directly to login page
            await this.page.goto('https://www.linkedin.com/login', { waitUntil: 'networkidle2' });
          }
        }
        
        // Wait for login form
        await this.page.waitForSelector('#username, #email-or-phone', { timeout: 10000 });
        
        // Fill in the username field
        try {
          await this.page.type('#username', username);
        } catch (e) {
          await this.page.type('#email-or-phone', username);
        }
        
        // Fill in the password field
        await this.page.type('#password', password);
        
        // Submit the form
        await Promise.all([
          this.page.click('button[type="submit"]'),
          this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 60000 })
        ]);
        
        // Check if login was successful by looking for elements that appear after login
        try {
          await this.page.waitForSelector('div[data-control-name="identity_welcome_message"], .feed-identity-module', { timeout: 10000 });
          step.success = true;
          step.message = 'Successfully authenticated with LinkedIn';
        } catch (e) {
          // Check for error messages
          const errorText = await this.page.evaluate(() => {
            const errorElement = document.querySelector('#error-for-username, #error-for-password, .alert-content');
            return errorElement ? errorElement.textContent : null;
          });
          
          if (errorText) {
            step.success = false;
            step.message = `Authentication failed: ${errorText.trim()}`;
          } else {
            // If we can't detect a specific error but we also don't see the dashboard
            // Take another approach - check URL to see if we're still on login page
            const newUrl = this.page.url();
            if (newUrl.includes('/login') || newUrl.includes('/checkpoint')) {
              step.success = false;
              step.message = 'Authentication failed: Still on login or security checkpoint page';
            } else {
              // Assume success if we navigated away from login page
              step.success = true;
              step.message = 'Likely authenticated with LinkedIn (redirected from login page)';
            }
          }
        }
      } else {
        // Generic login form detection for other sites
        try {
          // Look for common login form elements
          const usernameSelectors = [
            'input[type="email"]', 
            'input[type="text"]', 
            'input[name="email"]', 
            'input[name="username"]',
            'input[id="email"]',
            'input[id="username"]'
          ];
          
          const passwordSelectors = [
            'input[type="password"]',
            'input[name="password"]',
            'input[id="password"]'
          ];
          
          // Find and fill username field
          for (const selector of usernameSelectors) {
            try {
              await this.page.waitForSelector(selector, { timeout: 2000 });
              await this.page.type(selector, username);
              break;
            } catch (e) {
              continue;
            }
          }
          
          // Find and fill password field
          for (const selector of passwordSelectors) {
            try {
              await this.page.waitForSelector(selector, { timeout: 2000 });
              await this.page.type(selector, password);
              break;
            } catch (e) {
              continue;
            }
          }
          
          // Look for submit button
          const submitSelectors = [
            'button[type="submit"]',
            'input[type="submit"]',
            'button:contains("Sign in")',
            'button:contains("Log in")',
            'button:contains("Login")'
          ];
          
          for (const selector of submitSelectors) {
            try {
              await this.page.waitForSelector(selector, { timeout: 2000 });
              await Promise.all([
                this.page.click(selector),
                this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
              ]);
              break;
            } catch (e) {
              continue;
            }
          }
          
          // Assume success if we don't encounter errors
          step.success = true;
          step.message = 'Attempted authentication with generic login form';
        } catch (e) {
          step.success = false;
          step.message = `Failed to authenticate with generic login form: ${e instanceof Error ? e.message : String(e)}`;
        }
      }
      
      this.taskSteps.push(step);
      return step.success || false;
    } catch (error) {
      console.error(`Error authenticating with ${username}:`, error);
      this.taskSteps.push({
        type: 'authentication',
        action: 'sign in',
        data: { username },
        success: false,
        message: `Failed to authenticate: ${error instanceof Error ? error.message : String(error)}`
      });
      return false;
    }
  }

  /**
   * Apply to jobs
   * @param count Number of jobs to apply to
   */
  private async applyToJobs(count: number): Promise<boolean> {
    try {
      if (!this.page) {
        throw new Error('Browser not initialized');
      }
      
      const step: TaskStep = {
        type: 'application',
        action: 'apply to jobs',
        data: { count }
      };
      
      // Detect if we're on LinkedIn jobs page
      const currentUrl = this.page.url();
      const isLinkedInJobs = currentUrl.includes('linkedin.com/jobs');
      
      let appliedCount = 0;
      
      if (isLinkedInJobs) {
        // We're on LinkedIn jobs page, look for job listings
        try {
          // Wait for job listings to load
          await this.page.waitForSelector('.jobs-search-results__list', { timeout: 10000 });
          
          // Get all job cards
          const jobCards = await this.page.$$('.jobs-search-results__list-item');
          
          if (jobCards.length === 0) {
            step.success = false;
            step.message = 'No job listings found';
            this.taskSteps.push(step);
            return false;
          }
          
          // Click on each job card and apply
          for (let i = 0; i < Math.min(count, jobCards.length); i++) {
            try {
              // Click on the job card to view details
              await jobCards[i].click();
              
              // Wait for job details to load
              await this.page.waitForSelector('.jobs-details', { timeout: 5000 });
              
              // Check if there's an Easy Apply button
              const easyApplyButton = await this.page.$('.jobs-apply-button');
              
              if (easyApplyButton) {
                // Click the Easy Apply button
                await easyApplyButton.click();
                
                // Wait for the application form to appear
                await this.page.waitForSelector('.jobs-easy-apply-content', { timeout: 5000 });
                
                // Fill in the application form
                await this.fillForms();
                
                // Increment the count of applied jobs
                appliedCount++;
                
                // Close the application form if still open
                try {
                  const closeButton = await this.page.$('.artdeco-modal__dismiss');
                  if (closeButton) {
                    await closeButton.click();
                  }
                } catch (e) {
                  // Ignore errors when closing the form
                }
              } else {
                // If there's no Easy Apply button, try looking for an external apply button
                const externalApplyButton = await this.page.$('a[data-control-name="job_details_apply_link_offsite"]');
                
                if (externalApplyButton) {
                  // Open the external application in a new tab
                  const newPagePromise = new Promise<puppeteer.Page>(resolve => {
                    this.browser!.once('targetcreated', target => resolve(target.page()));
                  });
                  
                  await externalApplyButton.click();
                  const newPage = await newPagePromise;
                  
                  if (newPage) {
                    // Wait for the page to load
                    await newPage.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 });
                    
                    // Fill in the application form
                    // This is simplified and would need to be expanded for real use
                    // as external application forms vary widely
                    await this.fillFormsOnPage(newPage);
                    
                    // Close the external application tab
                    await newPage.close();
                    
                    // Increment the count of applied jobs
                    appliedCount++;
                  }
                }
              }
            } catch (e) {
              console.error(`Error applying to job ${i + 1}:`, e);
              // Continue to the next job if there's an error
            }
            
            // Wait a bit before moving to the next job to avoid rate limiting
            await this.page.waitForTimeout(2000);
          }
          
          step.success = appliedCount > 0;
          step.message = `Applied to ${appliedCount} job${appliedCount !== 1 ? 's' : ''}`;
        } catch (e) {
          step.success = false;
          step.message = `Failed to apply to jobs: ${e instanceof Error ? e.message : String(e)}`;
        }
      } else {
        // Not on LinkedIn jobs page
        step.success = false;
        step.message = 'Not on a recognized job listing page';
      }
      
      this.taskSteps.push(step);
      return step.success || false;
    } catch (error) {
      console.error(`Error applying to jobs:`, error);
      this.taskSteps.push({
        type: 'application',
        action: 'apply to jobs',
        success: false,
        message: `Failed to apply to jobs: ${error instanceof Error ? error.message : String(error)}`
      });
      return false;
    }
  }

  /**
   * Fill in forms on the current page
   */
  private async fillForms(): Promise<boolean> {
    if (!this.page) {
      throw new Error('Browser not initialized');
    }
    
    return this.fillFormsOnPage(this.page);
  }

  /**
   * Fill in forms on a specific page
   * @param page The page to fill forms on
   */
  private async fillFormsOnPage(page: puppeteer.Page): Promise<boolean> {
    try {
      const step: TaskStep = {
        type: 'form',
        action: 'fill forms'
      };
      
      // Check if we're on LinkedIn
      const currentUrl = page.url();
      const isLinkedIn = currentUrl.includes('linkedin.com');
      
      if (isLinkedIn && currentUrl.includes('/jobs/')) {
        // LinkedIn job application form
        try {
          // Look for form fields
          const formFields = await page.$$('input, textarea, select');
          
          for (const field of formFields) {
            const tagName = await page.evaluate((el: Element) => el.tagName.toLowerCase(), field);
            const type = await page.evaluate((el: HTMLInputElement) => el.type, field);
            const name = await page.evaluate((el: HTMLInputElement) => el.name, field);
            const id = await page.evaluate((el: HTMLElement) => el.id, field);
            const placeholder = await page.evaluate((el: HTMLInputElement) => el.placeholder, field);
            const ariaLabel = await page.evaluate((el: HTMLElement) => el.getAttribute('aria-label'), field);
            
            // Determine what kind of field this is
            let fieldType = 'unknown';
            if (type === 'email' || name.includes('email') || id.includes('email') || placeholder?.includes('email') || ariaLabel?.includes('email')) {
              fieldType = 'email';
            } else if (type === 'tel' || name.includes('phone') || id.includes('phone') || placeholder?.includes('phone') || ariaLabel?.includes('phone')) {
              fieldType = 'phone';
            } else if (name.includes('name') || id.includes('name') || placeholder?.includes('name') || ariaLabel?.includes('name')) {
              fieldType = 'name';
            } else if (tagName === 'textarea' || name.includes('cover') || id.includes('cover') || placeholder?.includes('cover') || ariaLabel?.includes('cover')) {
              fieldType = 'coverLetter';
            } else if (name.includes('experience') || id.includes('experience') || placeholder?.includes('experience') || ariaLabel?.includes('experience')) {
              fieldType = 'experience';
            } else if (name.includes('education') || id.includes('education') || placeholder?.includes('education') || ariaLabel?.includes('education')) {
              fieldType = 'education';
            } else if (name.includes('skill') || id.includes('skill') || placeholder?.includes('skill') || ariaLabel?.includes('skill')) {
              fieldType = 'skills';
            }
            
            // Fill the field based on its type
            switch (fieldType) {
              case 'email':
                await field.type('billywhitemusic@gmail.com');
                break;
              case 'phone':
                await field.type('5551234567');
                break;
              case 'name':
                await field.type('Billy White');
                break;
              case 'coverLetter':
                await field.type('I am an experienced music composer with a strong background in various musical styles including jazz, classical, and contemporary. My work has been featured in several productions, and I have a keen ability to create emotionally resonant compositions tailored to specific needs. I am excited about this opportunity and believe my skills would be a valuable addition to your team.');
                break;
              case 'experience':
                await field.type('10+ years of professional music composition experience. Worked with major studios and independent productions. Proficient in orchestral arrangement, jazz composition, and electronic music production.');
                break;
              case 'education':
                await field.type('Master of Music in Composition, Berklee College of Music');
                break;
              case 'skills':
                await field.type('Music Composition, Orchestration, Sound Design, ProTools, Logic Pro, Ableton Live, Sheet Music Preparation');
                break;
            }
          }
          
          // Look for Next, Submit, or Continue buttons
          const buttonSelectors = [
            'button[aria-label="Submit application"]',
            'button[aria-label="Continue to next step"]',
            'button[aria-label="Next"]',
            'button:contains("Submit")',
            'button:contains("Apply")',
            'button:contains("Next")',
            'button:contains("Continue")'
          ];
          
          for (const selector of buttonSelectors) {
            try {
              const button = await page.$(selector);
              if (button) {
                await button.click();
                // Wait a bit for the next step to load
                await page.waitForTimeout(2000);
              }
            } catch (e) {
              // Ignore errors and try the next button selector
            }
          }
          
          step.success = true;
          step.message = 'Filled LinkedIn job application form';
        } catch (e) {
          step.success = false;
          step.message = `Failed to fill LinkedIn application form: ${e instanceof Error ? e.message : String(e)}`;
        }
      } else {
        // Generic form filling
        try {
          // Look for common form fields
          const formFields = await page.$$('input, textarea, select');
          
          let filledFields = 0;
          
          for (const field of formFields) {
            const tagName = await page.evaluate((el: Element) => el.tagName.toLowerCase(), field);
            const type = await page.evaluate((el: HTMLInputElement) => el.type, field);
            
            if (type === 'hidden' || type === 'submit' || type === 'button') {
              continue;
            }
            
            if (tagName === 'input') {
              if (type === 'text' || type === 'email' || type === 'tel') {
                await field.type('Example text');
                filledFields++;
              } else if (type === 'checkbox') {
                await field.click();
                filledFields++;
              }
            } else if (tagName === 'textarea') {
              await field.type('Example textarea content');
              filledFields++;
            } else if (tagName === 'select') {
              // Select an option (usually the first one)
              await page.evaluate((el: HTMLSelectElement) => {
                if (el.options.length > 0) {
                  el.selectedIndex = 1; // Select the second option if available
                  el.dispatchEvent(new Event('change'));
                }
              }, field);
              filledFields++;
            }
          }
          
          // Look for submit button
          const submitButton = await page.$('button[type="submit"], input[type="submit"]');
          if (submitButton) {
            await submitButton.click();
          }
          
          step.success = filledFields > 0;
          step.message = `Filled ${filledFields} fields in generic form`;
        } catch (e) {
          step.success = false;
          step.message = `Failed to fill generic form: ${e instanceof Error ? e.message : String(e)}`;
        }
      }
      
      this.taskSteps.push(step);
      return step.success || false;
    } catch (error) {
      console.error(`Error filling forms:`, error);
      this.taskSteps.push({
        type: 'form',
        action: 'fill forms',
        success: false,
        message: `Failed to fill forms: ${error instanceof Error ? error.message : String(error)}`
      });
      return false;
    }
  }

  /**
   * Extract URL from an instruction
   * @param instruction The instruction that contains a URL
   */
  private extractUrl(instruction: string): string | null {
    const urlPattern = /(https?:\/\/[^\s]+)/;
    const match = instruction.match(urlPattern);
    return match ? match[1] : null;
  }

  /**
   * Extract credentials from an instruction
   * @param instruction The instruction that contains credentials
   */
  private extractCredentials(instruction: string): { username: string | null; password: string | null } {
    const usernamePattern = /username\s*[:|=]?\s*([^\s,]+)|email\s*[:|=]?\s*([^\s,]+)/i;
    const passwordPattern = /password\s*[:|=]?\s*([^\s,]+)|pw\s*[:|=]?\s*([^\s,]+)/i;
    
    const usernameMatch = instruction.match(usernamePattern);
    const passwordMatch = instruction.match(passwordPattern);
    
    return {
      username: usernameMatch ? usernameMatch[1] || usernameMatch[2] : null,
      password: passwordMatch ? passwordMatch[1] || passwordMatch[2] : null
    };
  }

  /**
   * Extract a number from an instruction
   * @param instruction The instruction that may contain a number
   */
  private extractCount(instruction: string): number | null {
    const countPattern = /(\d+)\s*(job|jobs|position|positions)/i;
    const match = instruction.match(countPattern);
    return match ? parseInt(match[1], 10) : null;
  }
}

/**
 * Process a web task with the given instructions
 * @param instructions List of instructions to execute
 */
export async function processWebTask(instructions: string[]): Promise<WebTaskResult> {
  const agent = new WebAgent();
  try {
    return await agent.executeTask(instructions);
  } finally {
    await agent.cleanup();
  }
}