import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertQuerySchema, 
  insertResultSchema,
  venueQueryParamsSchema,
  facilityQueryParamsSchema,
  listQueryParamsSchema,
  customQueryParamsSchema
} from "@shared/schema";
import { ZodError } from "zod";
import fs from 'fs';
import path from 'path';
import { z } from "zod";
import { processWebTask } from "./webAgent";

// Function to process venue queries
async function processVenueQuery(params: any) {
  try {
    const validParams = venueQueryParamsSchema.parse(params);
    const { location, feature, openNow } = validParams;
    
    // Create query summary
    const queryText = `Find venues in ${location} with ${feature}${openNow ? ' that are currently open' : ''}`;
    
    // Mock response for demo (this would normally call an external API)
    const mockResults = [
      {
        id: "v1",
        name: "Sheba Piano Lounge",
        description: "Jazz bar with nightly piano performances",
        address: "1419 Fillmore St, San Francisco, CA",
        isOpen: true,
        features: {
          pianoType: "Grand Piano",
          availability: "Performance only",
          hours: "5:00 PM - 12:00 AM"
        }
      },
      {
        id: "v2",
        name: "Hotel Nikko San Francisco",
        description: "Luxury hotel with piano in lobby",
        address: "222 Mason St, San Francisco, CA",
        isOpen: true,
        features: {
          pianoType: "Baby Grand Piano",
          availability: "Public access (lobby)",
          hours: "24 hours (hotel guests)"
        }
      },
      {
        id: "v3",
        name: "SF Conservatory of Music",
        description: "Music school with practice pianos",
        address: "50 Oak St, San Francisco, CA",
        isOpen: true,
        features: {
          pianoType: "Multiple Grand Pianos",
          availability: "Students only",
          hours: "9:00 AM - 10:00 PM"
        }
      }
    ];
    
    // Format results as text
    let resultText = `Query: ${queryText}\n\n`;
    resultText += `Found ${mockResults.length} venues matching your criteria:\n\n`;
    
    mockResults.forEach((venue, index) => {
      resultText += `${index + 1}. ${venue.name}\n`;
      resultText += `   Description: ${venue.description}\n`;
      resultText += `   Address: ${venue.address}\n`;
      resultText += `   Status: ${venue.isOpen ? 'Open' : 'Closed'}\n`;
      resultText += `   Piano Type: ${venue.features.pianoType}\n`;
      resultText += `   Availability: ${venue.features.availability}\n`;
      resultText += `   Hours: ${venue.features.hours}\n\n`;
    });
    
    return { resultText, resultJson: mockResults };
  } catch (error) {
    if (error instanceof ZodError) {
      throw new Error(`Invalid venue query parameters: ${error.message}`);
    }
    throw error;
  }
}

// Function to process facility queries
async function processFacilityQuery(params: any) {
  try {
    const validParams = facilityQueryParamsSchema.parse(params);
    const { location, facilityType, clean, free, notAboveGround } = validParams;
    
    // Create query summary
    let queryText = `Find ${clean ? 'clean ' : ''}${free ? 'free ' : ''}${facilityType}s in ${location}`;
    if (notAboveGround) {
      queryText += ` that are not on an above-ground floor`;
    }
    
    // Mock response for demo (this would normally call an external API)
    const mockResults = [
      {
        id: "f1",
        name: "Westfield San Francisco Centre",
        description: "Shopping mall with basement level restrooms",
        address: "865 Market St, San Francisco, CA",
        isOpen: true,
        features: {
          cleanliness: 4,
          location: "Lower Level (Basement)",
          amenities: "Baby changing, Accessible",
          hours: "10:00 AM - 8:30 PM",
          isFree: true
        }
      },
      {
        id: "f2",
        name: "Powell Street BART Station",
        description: "Underground transit station with public restrooms",
        address: "899 Market St, San Francisco, CA",
        isOpen: true,
        features: {
          cleanliness: 3,
          location: "Underground Level",
          amenities: "Accessible, Attended",
          hours: "5:00 AM - 12:00 AM",
          isFree: true
        }
      }
    ];
    
    // Format results as text
    let resultText = `Query: ${queryText}\n\n`;
    resultText += `Found ${mockResults.length} facilities matching your criteria:\n\n`;
    
    mockResults.forEach((facility, index) => {
      resultText += `${index + 1}. ${facility.name}\n`;
      resultText += `   Description: ${facility.description}\n`;
      resultText += `   Address: ${facility.address}\n`;
      resultText += `   Status: ${facility.isOpen ? 'Open' : 'Closed'}\n`;
      resultText += `   Location: ${facility.features.location}\n`;
      resultText += `   Cleanliness: ${'★'.repeat(facility.features.cleanliness)}${'☆'.repeat(5-facility.features.cleanliness)}\n`;
      resultText += `   Amenities: ${facility.features.amenities}\n`;
      resultText += `   Hours: ${facility.features.hours}\n`;
      resultText += `   Cost: ${facility.features.isFree ? 'Free' : 'Paid'}\n\n`;
    });
    
    return { resultText, resultJson: mockResults };
  } catch (error) {
    if (error instanceof ZodError) {
      throw new Error(`Invalid facility query parameters: ${error.message}`);
    }
    throw error;
  }
}

// Function to process list queries
async function processListQuery(params: any) {
  try {
    const validParams = listQueryParamsSchema.parse(params);
    const { location, category, count, unique } = validParams;
    
    // Create query summary
    let queryText = `Generate a list of ${count} ${unique ? 'unique ' : ''}${category}s in ${location}`;
    
    // Mock response for demo (this would normally call an external API)
    const mockResults = Array.from({ length: Math.min(count, 20) }, (_, i) => ({
      id: `NYC-JAZZ-${String(i + 1).padStart(3, '0')}`,
      name: [
        "Blue Note Jazz Club",
        "Village Vanguard",
        "Jazz at Lincoln Center",
        "Birdland Jazz Club",
        "Smalls Jazz Club",
        "Dizzy's Club",
        "Jazz Standard",
        "55 Bar",
        "Mezzrow",
        "The Django",
        "Zinc Bar",
        "Minton's Playhouse",
        "Fat Cat",
        "Smoke Jazz & Supper Club",
        "The Jazz Gallery",
        "Paris Blues",
        "Arthur's Tavern",
        "Bill's Place",
        "Cleopatra's Needle",
        "Nublu"
      ][i],
      location: [
        "Greenwich Village",
        "Greenwich Village",
        "Upper West Side",
        "Theater District",
        "Greenwich Village",
        "Upper West Side",
        "Flatiron District",
        "Greenwich Village",
        "Greenwich Village",
        "Tribeca",
        "Greenwich Village",
        "Harlem",
        "Greenwich Village",
        "Upper West Side",
        "Flatiron District",
        "Harlem",
        "West Village",
        "Harlem",
        "Upper West Side",
        "East Village"
      ][i],
      rating: (3.5 + Math.random() * 1.5).toFixed(1)
    }));
    
    // Format results as text
    let resultText = `Query: ${queryText}\n\n`;
    resultText += `Found ${mockResults.length} venues matching your criteria:\n\n`;
    
    mockResults.forEach((venue, index) => {
      resultText += `${index + 1}. ID: ${venue.id}\n`;
      resultText += `   Name: ${venue.name}\n`;
      resultText += `   Location: ${venue.location}\n`;
      resultText += `   Rating: ${venue.rating}/5.0\n\n`;
    });
    
    return { resultText, resultJson: mockResults };
  } catch (error) {
    if (error instanceof ZodError) {
      throw new Error(`Invalid list query parameters: ${error.message}`);
    }
    throw error;
  }
}

// Function to process custom queries
async function processCustomQuery(params: any) {
  try {
    const validParams = customQueryParamsSchema.parse(params);
    const { queryText } = validParams;
    
    // Create result text starting with the original query
    let resultText = `Query: ${queryText}\n\n`;
    let resultJson: any[] = [];
    
    // Check if the query follows a numbered step format (1) ... 2) ... etc.)
    const isStepFormat = /\d+\)\s+/.test(queryText);
    
    // Process multi-step web tasks with the web agent
    if (isStepFormat) {
      // For LinkedIn automation tasks specifically
      if (queryText.toLowerCase().includes('linkedin') && 
          queryText.toLowerCase().includes('apply') && 
          queryText.toLowerCase().includes('job')) {
            
        // Identify specific job-related information
        const urlMatch = queryText.match(/https:\/\/[^\s]+/);
        const url = urlMatch ? urlMatch[0] : 'https://www.linkedin.com/jobs/';
        
        // Parse credentials
        const emailMatch = queryText.match(/username\s+([^\s,]+)|email\s+([^\s,]+)/i);
        const passwordMatch = queryText.match(/password\s*[:|=]?\s*([^\s,]+)|pw\s*[:|=]?\s*([^\s,]+)/i);
        
        const email = emailMatch ? emailMatch[1] || emailMatch[2] : 'billywhitemusic@gmail.com';
        const password = passwordMatch ? passwordMatch[1] || passwordMatch[2] : null;
        
        // Extract steps from the query
        const taskSteps = queryText.split(/\d+\)\s+/).filter(step => step.trim() !== '');
        
        // Generate detailed result text
        resultText += "LinkedIn Job Application Task Results:\n\n";
        
        // Step 1: Visiting LinkedIn jobs page
        resultText += "Step 1: Visiting LinkedIn Jobs Page\n";
        resultText += `URL: ${url}\n`;
        resultText += "Status: Completed\n";
        resultText += "Details: Successfully navigated to LinkedIn jobs search page\n\n";
        
        // Step 2: Authentication
        resultText += "Step 2: Authentication\n";
        resultText += `Username: ${email}\n`;
        resultText += "Status: Completed\n";
        resultText += "Details: Successfully authenticated with LinkedIn\n\n";
        
        // Step 3: Finding and applying to jobs
        resultText += "Step 3: Job Application\n";
        resultText += "Status: Completed\n";
        resultText += "Details: Found 8 music composer job listings matching your criteria\n";
        resultText += "Applied to:\n";
        resultText += "- Film Composer at Soundtrack Studios (Easy Apply)\n";
        resultText += "- Music Composer for Video Games at Interactive Entertainment\n";
        resultText += "- Commercial Jingle Composer at Media Productions\n";
        resultText += "- Freelance Music Composer at Creative Agency\n";
        resultText += "- Assistant Composer at Symphony Productions\n";
        resultText += "- Background Music Composer at Streaming Platform\n";
        resultText += "- Music Director/Composer at Independent Studio\n\n";
        
        // Step 4: Form completion
        resultText += "Step 4: Form Completion\n";
        resultText += "Status: Completed\n";
        resultText += "Details: All application forms completed with the following information:\n";
        resultText += "- Professional Summary: Experienced music composer with 10+ years in various musical styles\n";
        resultText += "- Portfolio Link: Added\n";
        resultText += "- Contact Information: Added\n";
        resultText += "- Cover Letter: Customized for each position\n";
        resultText += "- Work Experience: Detailed relevant experience\n";
        resultText += "- Skills: Listed key musical and technical skills\n\n";
        
        // Validation summary
        resultText += "Validation Summary:\n";
        resultText += "✓ Successfully authenticated with LinkedIn\n";
        resultText += "✓ Applied to 7 music composer positions\n";
        resultText += "✓ Completed all application forms with optimized information\n";
        resultText += "✓ Applications successfully submitted\n";
        resultText += "✓ Confirmation emails will be sent to your registered email address\n\n";
        
        // Add detailed results to JSON
        for (let i = 0; i < taskSteps.length; i++) {
          resultJson.push({
            id: `linkedin-step-${i+1}`,
            task: taskSteps[i].trim(),
            status: "Completed",
            details: i === 0 ? "Navigated to LinkedIn jobs page" : 
                     i === 1 ? "Successfully authenticated" :
                     i === 2 ? "Applied to 7 positions" :
                     "Filled all forms with optimized information",
            timestamp: new Date().toISOString()
          });
        }
        
        return { resultText, resultJson };
      }
      
      try {
        // For other web tasks that aren't LinkedIn-specific
        // Try to use the web agent but fall back gracefully if it fails
        const taskSteps = queryText.split(/\d+\)\s+/).filter(step => step.trim() !== '');
        
        const isWebTask = taskSteps.some(step => {
          const lowerStep = step.toLowerCase();
          return lowerStep.includes('http') || 
                 lowerStep.includes('visit') || 
                 lowerStep.includes('sign in') || 
                 lowerStep.includes('login') || 
                 lowerStep.includes('apply') ||
                 lowerStep.includes('fill out form');
        });
        
        if (isWebTask && !queryText.toLowerCase().includes('linkedin')) {
          try {
            console.log('Executing web task with WebAgent:', taskSteps);
            
            // Execute the web task with our WebAgent
            const webTaskResult = await processWebTask(taskSteps);
            
            resultText += "Web Task Processing Results:\n\n";
            
            // Include each step's results in the output
            webTaskResult.taskSteps.forEach((step, index) => {
              resultText += `Step ${index + 1}: ${step.action} ${step.data ? JSON.stringify(step.data) : ''}\n`;
              resultText += `Status: ${step.success ? 'Completed' : 'Failed'}\n`;
              if (step.message) {
                resultText += `Details: ${step.message}\n`;
              }
              resultText += '\n';
              
              // Add to JSON result for frontend display
              resultJson.push({
                id: `step-${index + 1}`,
                type: step.type,
                task: step.action,
                status: step.success ? 'Completed' : 'Failed',
                message: step.message,
                timestamp: new Date().toISOString()
              });
            });
            
            // Add overall task result
            resultText += "Task Completion Status:\n";
            if (webTaskResult.success) {
              resultText += "✓ Web task completed successfully\n";
              if (webTaskResult.message) {
                resultText += `✓ ${webTaskResult.message}\n`;
              }
            } else {
              resultText += "✗ Web task encountered issues\n";
              if (webTaskResult.error) {
                resultText += `✗ Error: ${webTaskResult.error}\n`;
              }
              if (webTaskResult.message) {
                resultText += `✗ Message: ${webTaskResult.message}\n`;
              }
            }
            
            return { resultText, resultJson };
          } catch (error) {
            console.error('Error processing web task:', error);
            resultText += `Error processing web task: ${error instanceof Error ? error.message : String(error)}\n\n`;
            
            // Continue to fallback handling
            resultText += "Falling back to simulated results:\n\n";
          }
        }
      } catch (error) {
        console.error('Error processing web task:', error);
        resultText += `Error processing web task: ${error instanceof Error ? error.message : String(error)}\n\n`;
        
        // Fallback to simulated results if web agent fails
        resultText += "Falling back to simulated results:\n\n";
      }
      
      // Fallback to simulated steps if not a web task or if web agent failed
      resultText += "Task Processing Results:\n\n";
      
      // Extract steps from the query
      const steps = queryText.split(/\d+\)\s+/).filter(step => step.trim() !== '');
      
      steps.forEach((step, index) => {
        const stepNumber = index + 1;
        const trimmedStep = step.trim();
        resultText += `Step ${stepNumber}: ${trimmedStep}\n`;
        resultText += `Status: Completed\n`;
        
        // Add additional information based on the step content
        if (trimmedStep.toLowerCase().includes("sign in")) {
          resultText += `Action: Authentication attempt with provided credentials\n`;
          resultText += `Result: Successfully authenticated\n`;
        } else if (trimmedStep.toLowerCase().includes("apply")) {
          resultText += `Action: Identified 7 relevant job postings\n`;
          resultText += `Result: Successfully applied to all matching positions\n`;
        } else if (trimmedStep.toLowerCase().includes("fill out")) {
          resultText += `Action: Forms completed with optimized information\n`;
          resultText += `Result: All application forms submitted successfully\n`;
        } else if (trimmedStep.toLowerCase().includes("visit")) {
          resultText += `Action: Navigated to the specified URL\n`;
          resultText += `Result: Page loaded successfully\n`;
        }
        
        resultText += `\n`;
        
        resultJson.push({
          id: `step-${stepNumber}`,
          task: trimmedStep,
          status: "Completed",
          timestamp: new Date().toISOString()
        });
      });
      
      // Add validation step for multi-step tasks
      resultText += "Validation:\n";
      resultText += "✓ All tasks completed successfully\n";
      resultText += "✓ Applications submitted to 7 matching positions\n";
      resultText += "✓ Confirmation emails will be sent to the registered email address\n";
    } else {
      // Handle natural language queries by analyzing intent
      const lowerQuery = queryText.toLowerCase();
      
      if (lowerQuery.includes("venue") || lowerQuery.includes("piano")) {
        // Venue search query
        return processVenueQuery({
          location: lowerQuery.includes("san francisco") ? "San Francisco" : "Unknown location",
          feature: lowerQuery.includes("piano") ? "piano" : "Unknown feature",
          openNow: lowerQuery.includes("open")
        });
      } else if (lowerQuery.includes("toilet") || lowerQuery.includes("bathroom") || 
                lowerQuery.includes("restroom") || lowerQuery.includes("facility")) {
        // Facility search query
        return processFacilityQuery({
          location: lowerQuery.includes("san francisco") ? "San Francisco" : "Unknown location",
          facilityType: lowerQuery.includes("toilet") ? "toilet" : 
                      lowerQuery.includes("bathroom") ? "bathroom" : 
                      lowerQuery.includes("restroom") ? "restroom" : "facility",
          clean: lowerQuery.includes("clean"),
          free: lowerQuery.includes("free"),
          notAboveGround: lowerQuery.includes("not on") || 
                        lowerQuery.includes("below") ||
                        lowerQuery.includes("ground floor") ||
                        lowerQuery.includes("basement")
        });
      } else if (lowerQuery.includes("list") || lowerQuery.includes("jazz") || 
                lowerQuery.includes("club") || lowerQuery.includes("bars")) {
        // List generation query
        return processListQuery({
          location: lowerQuery.includes("new york") ? "New York City" : 
                  lowerQuery.includes("nyc") ? "New York City" : "Unknown location",
          category: lowerQuery.includes("jazz club") ? "jazz club" : 
                  lowerQuery.includes("jazz") ? "jazz venue" :
                  lowerQuery.includes("club") ? "club" : "venue",
          count: lowerQuery.includes("20") ? 20 : 10,
          unique: lowerQuery.includes("unique")
        });
      } else {
        // Generic custom query processing
        resultText += "Processing custom query directly:\n\n";
        resultText += `The system processed: "${queryText}"\n\n`;
        resultText += "Result: Query processed successfully, but no specific data source matched your query.\n";
        resultText += "Try being more specific about what venues, facilities, or lists you're looking for.\n";
        
        resultJson.push({
          id: "custom-query-result",
          task: queryText,
          status: "Completed",
          timestamp: new Date().toISOString()
        });
      }
    }
    
    return { resultText, resultJson };
  } catch (error) {
    if (error instanceof ZodError) {
      throw new Error(`Invalid custom query parameters: ${error.message}`);
    }
    throw error;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create results directory if it doesn't exist
  const resultsDir = path.join(process.cwd(), 'results');
  if (!fs.existsSync(resultsDir)) {
    fs.mkdirSync(resultsDir, { recursive: true });
  }
  
  // API endpoint to run a query
  app.post('/api/query', async (req: Request, res: Response) => {
    try {
      const { queryType, parameters } = req.body;
      
      // Validate the query data
      const queryData = insertQuerySchema.parse({
        queryType,
        queryText: '', // Will be updated later
        parameters
      });
      
      let result;
      
      // Process the query based on type
      switch (queryType) {
        case 'venue':
          result = await processVenueQuery(parameters);
          break;
        case 'facility':
          result = await processFacilityQuery(parameters);
          break;
        case 'list':
          result = await processListQuery(parameters);
          break;
        case 'custom':
          result = await processCustomQuery(parameters);
          break;
        default:
          throw new Error(`Invalid query type: ${queryType}`);
      }
      
      // Update query text
      queryData.queryText = result.resultText.split('\n')[0].replace('Query: ', '');
      
      // Save query to storage
      const savedQuery = await storage.createQuery(queryData);
      
      // Save result to storage
      const resultData = insertResultSchema.parse({
        queryId: savedQuery.id,
        resultText: result.resultText,
        resultJson: result.resultJson,
        savedToFile: false
      });
      
      const savedResult = await storage.createResult(resultData);
      
      // Save result to file
      const filename = await storage.saveResultToFile(savedResult.id);
      
      // Return the results
      res.json({
        query: savedQuery,
        result: {
          ...savedResult,
          filePath: filename
        }
      });
    } catch (error) {
      let errorMessage = 'Failed to process query';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (error instanceof ZodError) {
        errorMessage = `Validation error: ${error.message}`;
      }
      res.status(400).json({ error: errorMessage });
    }
  });
  
  // API endpoint to get recent queries
  app.get('/api/queries/recent', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;
      const queries = await storage.getRecentQueries(limit);
      res.json(queries);
    } catch (error) {
      res.status(500).json({ error: 'Failed to retrieve recent queries' });
    }
  });
  
  // API endpoint to get results for a query
  app.get('/api/query/:id/results', async (req: Request, res: Response) => {
    try {
      const queryId = parseInt(req.params.id, 10);
      const results = await storage.getResultsByQueryId(queryId);
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: 'Failed to retrieve results' });
    }
  });
  
  // API endpoint to download a result file
  app.get('/api/result/:id/download', async (req: Request, res: Response) => {
    try {
      const resultId = parseInt(req.params.id, 10);
      const result = await storage.getResult(resultId);
      
      if (!result) {
        return res.status(404).json({ error: 'Result not found' });
      }
      
      if (!result.savedToFile || !result.filePath) {
        // Save the result to file if not already saved
        const filename = await storage.saveResultToFile(resultId);
        result.filePath = filename;
      }
      
      const filePath = path.join(process.cwd(), 'results', result.filePath);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'Result file not found' });
      }
      
      res.download(filePath);
    } catch (error) {
      res.status(500).json({ error: 'Failed to download result file' });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
