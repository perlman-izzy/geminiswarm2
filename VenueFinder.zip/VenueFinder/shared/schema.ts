import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model (required for the existing schema)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Query model to store search queries
export const queries = pgTable("queries", {
  id: serial("id").primaryKey(),
  queryType: text("query_type").notNull(), // 'venue', 'facility', 'list'
  queryText: text("query_text").notNull(),
  parameters: json("parameters").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertQuerySchema = createInsertSchema(queries).omit({
  id: true,
  createdAt: true,
});

export type InsertQuery = z.infer<typeof insertQuerySchema>;
export type Query = typeof queries.$inferSelect;

// Result model to store search results
export const results = pgTable("results", {
  id: serial("id").primaryKey(),
  queryId: integer("query_id").notNull(),
  resultText: text("result_text").notNull(),
  resultJson: json("result_json"),
  savedToFile: boolean("saved_to_file").default(false),
  filePath: text("file_path"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResultSchema = createInsertSchema(results).omit({
  id: true,
  createdAt: true,
});

export type InsertResult = z.infer<typeof insertResultSchema>;
export type Result = typeof results.$inferSelect;

// Query parameters schema definitions
export const venueQueryParamsSchema = z.object({
  location: z.string().min(1, "Location is required"),
  feature: z.string().min(1, "Feature is required"),
  openNow: z.boolean().optional(),
});

export const facilityQueryParamsSchema = z.object({
  location: z.string().min(1, "Location is required"),
  facilityType: z.string().min(1, "Facility type is required"),
  clean: z.boolean().optional(),
  free: z.boolean().optional(),
  notAboveGround: z.boolean().optional(),
});

export const listQueryParamsSchema = z.object({
  location: z.string().min(1, "Location is required"),
  category: z.string().min(1, "Category is required"),
  count: z.number().min(1).max(100),
  unique: z.boolean().optional(),
});

export const customQueryParamsSchema = z.object({
  queryText: z.string().min(1, "Query text is required"),
});

export type VenueQueryParams = z.infer<typeof venueQueryParamsSchema>;
export type FacilityQueryParams = z.infer<typeof facilityQueryParamsSchema>;
export type ListQueryParams = z.infer<typeof listQueryParamsSchema>;
export type CustomQueryParams = z.infer<typeof customQueryParamsSchema>;
